const DB_NAME = 'social_platform_db';
const DB_VERSION = 1;
let db;
let currentUser = null;
let deferredPrompt = null;
const channel = ('BroadcastChannel' in window) ? new BroadcastChannel('social_platform_chat') : null;

const $ = (id) => document.getElementById(id);

function uid(prefix='id'){
  return `${prefix}_${Math.random().toString(36).slice(2,10)}_${Date.now().toString(36)}`;
}

function formatTime(ts){
  return new Date(ts).toLocaleString([], {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'});
}

function toSafeText(v){
  return String(v ?? '').replace(/[<>&"]/g, s => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[s]));
}

function openDB(){
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      db = request.result;
      ['users','posts','comments','stories','reels','messages','assets','notifications'].forEach(store => {
        if (!db.objectStoreNames.contains(store)) {
          const os = db.createObjectStore(store, { keyPath: 'id' });
          os.createIndex('createdAt', 'createdAt');
        }
      });
    };
    request.onsuccess = () => { db = request.result; resolve(db); };
    request.onerror = () => reject(request.error);
  });
}

function tx(store, mode='readonly'){
  return db.transaction(store, mode).objectStore(store);
}

function idbGetAll(store){
  return new Promise((resolve, reject) => {
    const req = tx(store).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

function idbGet(store, id){
  return new Promise((resolve, reject) => {
    const req = tx(store).get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

function idbPut(store, value){
  return new Promise((resolve, reject) => {
    const req = tx(store, 'readwrite').put(value);
    req.onsuccess = () => resolve(value);
    req.onerror = () => reject(req.error);
  });
}

function idbAdd(store, value){
  return new Promise((resolve, reject) => {
    const req = tx(store, 'readwrite').add(value);
    req.onsuccess = () => resolve(value);
    req.onerror = () => reject(req.error);
  });
}

function idbClear(store){
  return new Promise((resolve, reject) => {
    const req = tx(store, 'readwrite').clear();
    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}

async function seedData(){
  const users = await idbGetAll('users');
  if (users.length === 0){
    const demo = {
      id: uid('user'),
      name: 'Demo Creator',
      password: '1234',
      role: 'admin',
      bio: 'Responsive social UI showcase',
      createdAt: Date.now()
    };
    await idbAdd('users', demo);
    await idbAdd('posts', {
      id: uid('post'),
      userId: demo.id,
      text: 'Welcome to the advanced social platform prototype ✨',
      media: '',
      likes: 19,
      createdAt: Date.now()
    });
    await idbAdd('stories', {
      id: uid('story'),
      userId: demo.id,
      media: '',
      type: 'image',
      caption: 'New story',
      createdAt: Date.now(),
      expiresAt: Date.now() + 24*60*60*1000
    });
    await idbAdd('reels', {
      id: uid('reel'),
      userId: demo.id,
      media: '',
      caption: 'Vertical reel preview',
      createdAt: Date.now()
    });
    await idbAdd('messages', {
      id: uid('msg'),
      from: 'System',
      to: demo.id,
      text: 'Real-time backend is ready for connection.',
      createdAt: Date.now()
    });
    await idbAdd('assets', {
      id: uid('asset'),
      userId: demo.id,
      name: 'Cloud storage placeholder',
      type: 'text/plain',
      size: 12,
      url: '',
      createdAt: Date.now()
    });
  }
}

async function loadCurrentUser(){
  const id = localStorage.getItem('social_current_user');
  if (!id) return null;
  return await idbGet('users', id);
}

async function setCurrentUser(user){
  currentUser = user;
  if (user) localStorage.setItem('social_current_user', user.id);
  else localStorage.removeItem('social_current_user');
  renderUser();
  renderAll();
}

function renderUser(){
  $('currentUserLabel').textContent = currentUser ? currentUser.name : 'Guest';
  $('profileName').textContent = currentUser ? currentUser.name : 'Demo Creator';
  $('profileBio').textContent = currentUser ? currentUser.bio : 'Modern UI Showcase';
  $('avatarCircle').textContent = (currentUser ? currentUser.name : 'A').slice(0,1).toUpperCase();
}

async function registerUser(name, password){
  const clean = name.trim();
  if (!clean || !password) throw new Error('Username and password are required');
  const users = await idbGetAll('users');
  if (users.some(u => u.name.toLowerCase() === clean.toLowerCase())) throw new Error('Username already exists');
  const user = {
    id: uid('user'),
    name: clean,
    password,
    role: 'user',
    bio: 'New community member',
    createdAt: Date.now()
  };
  await idbAdd('users', user);
  return user;
}

async function loginUser(name, password){
  const users = await idbGetAll('users');
  return users.find(u => u.name.toLowerCase() === name.trim().toLowerCase() && u.password === password) || null;
}

async function addPost(text, file){
  const media = file ? await fileToDataUrl(file) : '';
  const post = {
    id: uid('post'),
    userId: currentUser.id,
    text: text.trim(),
    media,
    likes: 0,
    createdAt: Date.now()
  };
  await idbAdd('posts', post);
  await addNotification(`${currentUser.name} published a post`);
  broadcast({type:'post', payload: post});
}

async function addComment(postId, text){
  const comment = {
    id: uid('comment'),
    postId,
    userId: currentUser?.id || 'guest',
    text: text.trim(),
    createdAt: Date.now()
  };
  await idbAdd('comments', comment);
}

async function addStory(file){
  const media = file ? await fileToDataUrl(file) : '';
  await idbAdd('stories', {
    id: uid('story'),
    userId: currentUser.id,
    media,
    type: file?.type?.startsWith('video') ? 'video' : 'image',
    caption: 'Story by ' + currentUser.name,
    createdAt: Date.now(),
    expiresAt: Date.now() + 24*60*60*1000
  });
  await addNotification('Story uploaded');
}

async function addReel(file, caption){
  const media = file ? await fileToDataUrl(file) : '';
  await idbAdd('reels', {
    id: uid('reel'),
    userId: currentUser.id,
    media,
    caption: caption.trim() || 'New reel',
    createdAt: Date.now()
  });
  await addNotification('Reel uploaded');
}

async function addAsset(file){
  const media = file ? await fileToDataUrl(file) : '';
  await idbAdd('assets', {
    id: uid('asset'),
    userId: currentUser.id,
    name: file?.name || 'Unnamed asset',
    type: file?.type || 'application/octet-stream',
    size: file?.size || 0,
    url: media,
    createdAt: Date.now()
  });
}

async function addNotification(text){
  await idbAdd('notifications', {
    id: uid('note'),
    text,
    createdAt: Date.now()
  });
  if (Notification.permission === 'granted') {
    new Notification('Social Platform', { body: text });
  }
}

function broadcast(message){
  if (channel) channel.postMessage(message);
}

async function sendChat(text){
  const body = text.trim();
  if (!body) return;
  await idbAdd('messages', {
    id: uid('msg'),
    from: currentUser?.name || 'Guest',
    to: 'all',
    text: body,
    createdAt: Date.now()
  });
  broadcast({type:'message', payload: body});
  setTimeout(async () => {
    const reply = [
      'Backend ack received.',
      'Message synced across devices.',
      'Realtime update delivered.'
    ][Math.floor(Math.random()*3)];
    await idbAdd('messages', {
      id: uid('msg'),
      from: 'System Bot',
      to: currentUser?.name || 'Guest',
      text: reply,
      createdAt: Date.now()
    });
    renderMessages();
  }, 1800);
}

function fileToDataUrl(file){
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function escapeHtml(str){
  return toSafeText(str);
}

async function renderStories(){
  const stories = (await idbGetAll('stories'))
    .filter(s => s.expiresAt > Date.now())
    .sort((a,b)=>b.createdAt - a.createdAt);
  $('storiesRow').innerHTML = stories.map(story => {
    const letter = (story.caption || 'S').slice(0,1).toUpperCase();
    const media = story.media
      ? `<img src="${story.media}" alt="story">`
      : `<span>${letter}</span>`;
    return `<div class="story" title="${escapeHtml(story.caption)}">${media}</div>`;
  }).join('') || `<div class="tiny muted">No stories yet</div>`;
}

async function renderPosts(){
  const [posts, comments, users] = await Promise.all([
    idbGetAll('posts'),
    idbGetAll('comments'),
    idbGetAll('users')
  ]);
  const sorted = posts.sort((a,b)=>b.createdAt-a.createdAt);
  $('feedList').innerHTML = sorted.map(post => {
    const user = users.find(u => u.id === post.userId) || {name:'Unknown'};
    const postComments = comments.filter(c => c.postId === post.id);
    const media = post.media
      ? (post.media.startsWith('data:video/')
          ? `<video class="post-media" controls src="${post.media}"></video>`
          : `<img class="post-media" src="${post.media}" alt="post media">`)
      : '';
    return `
      <article class="post">
        <div class="post-head">
          <div>
            <strong>${escapeHtml(user.name)}</strong>
            <div class="post-meta">${formatTime(post.createdAt)}</div>
          </div>
          <button class="ghost" data-like="${post.id}">❤️ ${post.likes || 0}</button>
        </div>
        <div class="post-body">
          <p>${escapeHtml(post.text)}</p>
        </div>
        ${media}
        <div class="post-body post-actions">
          <button class="ghost" data-comment-focus="${post.id}">💬 ${postComments.length}</button>
          <span class="tiny">Real-time ready</span>
        </div>
        <div class="comments">
          ${postComments.slice(-3).map(c => `<div class="comment"><strong>${escapeHtml((users.find(u=>u.id===c.userId)||{name:'Guest'}).name)}:</strong> ${escapeHtml(c.text)}</div>`).join('') || '<div class="tiny muted">No comments yet</div>'}
        </div>
        <div class="comment-box">
          <input placeholder="Write a comment" data-comment-input="${post.id}">
          <button class="primary" data-comment-send="${post.id}">Send</button>
        </div>
      </article>
    `;
  }).join('') || `<div class="tiny muted">No posts yet</div>`;

  document.querySelectorAll('[data-like]').forEach(btn => {
    btn.onclick = async () => {
      const post = await idbGet('posts', btn.dataset.like);
      if (!post) return;
      post.likes = (post.likes || 0) + 1;
      await idbPut('posts', post);
      renderPosts();
      refreshStats();
    };
  });
  document.querySelectorAll('[data-comment-send]').forEach(btn => {
    btn.onclick = async () => {
      const id = btn.dataset.commentSend;
      const input = document.querySelector(`[data-comment-input="${id}"]`);
      if (!input.value.trim()) return;
      await addComment(id, input.value);
      input.value = '';
      renderPosts();
      refreshStats();
    };
  });
  document.querySelectorAll('[data-comment-focus]').forEach(btn => {
    btn.onclick = () => {
      const input = document.querySelector(`[data-comment-input="${btn.dataset.commentFocus}"]`);
      input?.focus();
    };
  });
}

async function renderMessages(){
  const messages = (await idbGetAll('messages')).sort((a,b)=>a.createdAt-b.createdAt);
  $('chatList').innerHTML = messages.map(msg => {
    const me = currentUser && msg.from === currentUser.name;
    return `<div class="bubble ${me ? 'me' : 'them'}"><div class="message-head"><strong>${escapeHtml(msg.from)}</strong><span class="tiny">${formatTime(msg.createdAt)}</span></div><div>${escapeHtml(msg.text)}</div></div>`;
  }).join('');
  $('chatList').scrollTop = $('chatList').scrollHeight;
}

async function renderReels(){
  const reels = (await idbGetAll('reels')).sort((a,b)=>b.createdAt-a.createdAt);
  const users = await idbGetAll('users');
  $('reelsList').innerHTML = reels.map(reel => {
    const user = users.find(u => u.id === reel.userId) || {name:'Unknown'};
    const media = reel.media
      ? `<video controls playsinline src="${reel.media}"></video>`
      : `<div class="post-media" style="height:260px;display:grid;place-items:center;">▶ Reel preview</div>`;
    return `
      <div class="reel">
        ${media}
        <div class="caption">
          <strong>${escapeHtml(user.name)}</strong>
          <div>${escapeHtml(reel.caption)}</div>
          <div class="tiny">${formatTime(reel.createdAt)}</div>
        </div>
      </div>
    `;
  }).join('') || '<div class="tiny muted">No reels uploaded yet</div>';
}

async function renderAssets(){
  const assets = (await idbGetAll('assets')).sort((a,b)=>b.createdAt-a.createdAt);
  $('cloudList').innerHTML = assets.map(asset => {
    const preview = asset.url
      ? (asset.type.startsWith('image/')
          ? `<img class="post-media" src="${asset.url}" alt="${escapeHtml(asset.name)}">`
          : asset.type.startsWith('video/')
            ? `<video class="post-media" controls src="${asset.url}"></video>`
            : `<div class="post-media" style="height:180px;display:grid;place-items:center;">📄 ${escapeHtml(asset.type)}</div>`)
      : `<div class="post-media" style="height:180px;display:grid;place-items:center;">☁ ${escapeHtml(asset.name)}</div>`;
    return `<div class="asset">${preview}<div class="caption"><strong>${escapeHtml(asset.name)}</strong><div class="tiny">${asset.type} • ${(asset.size/1024).toFixed(1)} KB</div></div></div>`;
  }).join('') || '<div class="tiny muted">No assets saved yet</div>';
}

async function refreshStats(){
  const [users, posts, messages, assets, stories, reels] = await Promise.all([
    idbGetAll('users'), idbGetAll('posts'), idbGetAll('messages'), idbGetAll('assets'), idbGetAll('stories'), idbGetAll('reels')
  ]);
  $('statUsers').textContent = users.length;
  $('statPosts').textContent = posts.length;
  $('statMsgs').textContent = messages.length;
  $('statMedia').textContent = assets.length + stories.length + reels.length;
  $('barPosts').style.width = `${Math.max(12, Math.min(100, posts.length * 14))}%`;
  $('barStories').style.width = `${Math.max(12, Math.min(100, stories.length * 14))}%`;
  $('barReels').style.width = `${Math.max(12, Math.min(100, reels.length * 14))}%`;
  $('barMessages').style.width = `${Math.max(12, Math.min(100, messages.length * 6))}%`;
}

async function renderAll(){
  if (!db) return;
  await Promise.all([renderStories(), renderPosts(), renderMessages(), renderReels(), renderAssets(), refreshStats()]);
}

function setDevice(device){
  const frame = $('deviceFrame');
  frame.classList.remove('phone', 'tablet', 'desktop');
  frame.classList.add(device);
}

function updateTime(){
  $('time').textContent = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
}

function bindEvents(){
  $('themeBtn').onclick = () => document.body.classList.toggle('light');
  $('signupBtn').onclick = async () => {
    try{
      const user = await registerUser($('signupName').value, $('signupPass').value);
      await setCurrentUser(user);
      $('signupName').value = '';
      $('signupPass').value = '';
    }catch(err){ alert(err.message); }
  };
  $('loginBtn').onclick = async () => {
    try{
      const user = await loginUser($('loginName').value, $('loginPass').value);
      if (!user) throw new Error('Invalid login');
      await setCurrentUser(user);
      $('loginName').value = '';
      $('loginPass').value = '';
    }catch(err){ alert(err.message); }
  };
  $('logoutBtn').onclick = () => setCurrentUser(null);
  $('postBtn').onclick = async () => {
    try{
      if (!currentUser) throw new Error('Please login first');
      const text = $('postText').value.trim();
      const file = $('postMedia').files[0];
      if (!text && !file) throw new Error('Write something or attach media');
      await addPost(text || 'Media post', file);
      $('postText').value = '';
      $('postMedia').value = '';
      await renderAll();
    }catch(err){ alert(err.message); }
  };
  $('storyBtn').onclick = async () => {
    try{
      if (!currentUser) throw new Error('Please login first');
      const file = $('storyFile').files[0];
      if (!file) throw new Error('Choose a story image or video');
      await addStory(file);
      $('storyFile').value = '';
      await renderAll();
    }catch(err){ alert(err.message); }
  };
  $('reelBtn').onclick = async () => {
    try{
      if (!currentUser) throw new Error('Please login first');
      const file = $('reelFile').files[0];
      if (!file) throw new Error('Choose a reel video');
      await addReel(file, $('reelCaption').value);
      $('reelFile').value = '';
      $('reelCaption').value = '';
      await renderAll();
    }catch(err){ alert(err.message); }
  };
  $('chatBtn').onclick = async () => {
    try{
      if (!currentUser) throw new Error('Please login first');
      const value = $('chatInput').value;
      $('chatInput').value = '';
      await sendChat(value);
      await renderMessages();
      refreshStats();
    }catch(err){ alert(err.message); }
  };
  $('chatInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') $('chatBtn').click();
  });
  $('cloudBtn').onclick = async () => {
    try{
      if (!currentUser) throw new Error('Please login first');
      const file = $('cloudFile').files[0];
      if (!file) throw new Error('Choose a file first');
      await addAsset(file);
      $('cloudFile').value = '';
      await renderAssets();
      refreshStats();
    }catch(err){ alert(err.message); }
  };
  $('pushTestBtn').onclick = async () => {
    if (Notification.permission !== 'granted') {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') return alert('Notification permission denied');
    }
    new Notification('Push preview', { body: 'This is a test notification from your social platform.' });
    await addNotification('Push test sent');
    renderAll();
  };
  $('notifyBtn').onclick = async () => {
    const perm = await Notification.requestPermission();
    alert(`Notifications: ${perm}`);
  };
  $('deviceSelect').onchange = e => setDevice(e.target.value);
  $('refreshSW').onclick = async () => {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      await reg.update();
      alert('Service worker updated');
    } else {
      alert('Service worker not supported');
    }
  };
  $('openReadme').onclick = () => $('setupDialog').showModal();
  $('closeDialog').onclick = () => $('setupDialog').close();
}

async function setupPWA(){
  if ('serviceWorker' in navigator) {
    try { await navigator.serviceWorker.register('./sw.js'); } catch (e) {}
  }
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    $('installBtn').classList.remove('hidden');
  });
  $('installBtn').onclick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    $('installBtn').classList.add('hidden');
  };
}

function realtimeHooks(){
  if (channel) {
    channel.onmessage = async (e) => {
      if (e.data?.type === 'message' || e.data?.type === 'post') {
        await renderAll();
      }
    };
  }
  setInterval(async () => {
    updateTime();
    const msgs = await idbGetAll('messages');
    if (msgs.length) {
      const last = msgs[msgs.length - 1];
      if (last && Math.random() < 0.04) {
        await idbAdd('notifications', {
          id: uid('note'),
          text: `Live update: ${last.from} said "${last.text.slice(0,24)}"`,
          createdAt: Date.now()
        });
      }
    }
  }, 1000);
}

(async function init(){
  await openDB();
  await seedData();
  currentUser = await loadCurrentUser();
  renderUser();
  bindEvents();
  await setupPWA();
  await renderAll();
  updateTime();
  realtimeHooks();
  setInterval(refreshStats, 5000);
})();
