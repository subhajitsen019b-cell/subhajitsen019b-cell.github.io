const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);

const io = socketIO(server, {
  cors: { origin: "*" }
});

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.send('Social Media Backend Running');
});

io.on('connection', (socket) => {
  console.log('User connected');

  socket.on('chat-message', (msg) => {
    io.emit('chat-message', msg);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

server.listen(3000, () => {
  console.log('Server running on port 3000');
});