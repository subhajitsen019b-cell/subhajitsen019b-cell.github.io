# Public Developer API

Endpoints:
- /api/users
- /api/posts
- /api/reels
- /api/messages
- /api/notifications