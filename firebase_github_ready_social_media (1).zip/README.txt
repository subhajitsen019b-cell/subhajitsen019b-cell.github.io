Advanced Social UI Platform

Included features
- Real database integration through IndexedDB
- Login / signup system
- Real-time messaging UI with BroadcastChannel sync
- Story upload
- Video reels
- Feed comments
- Push notification support
- Cloud storage upload preview
- PWA support with manifest and service worker
- Admin analytics counters
- Multi-user system
- Live device simulator
- Advanced animations

Important note
- This package is a front-end prototype.
- It stores app data in the browser's IndexedDB.
- To connect a real server database, replace the data layer in script.js with Firebase, Supabase, Appwrite, or your own API.
- APK conversion needs a wrapper such as Capacitor, Cordova, or TWA after you point the app to a live backend.

How to use
1. Open index.html in a browser or host it on a web server.
2. Create a user account or log in with the demo account:
   Username: Demo Creator
   Password: 1234
3. Upload posts, stories, reels, and files.

Files
- index.html
- style.css
- script.js
- manifest.json
- sw.js
- README.txt
