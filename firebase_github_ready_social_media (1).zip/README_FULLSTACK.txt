FULL STACK SOCIAL MEDIA PLATFORM

INCLUDED:
- Frontend social media UI
- Backend Node.js server
- Firebase config template
- Realtime Socket.io structure
- Database schema
- Cloud storage setup structure
- Admin analytics
- Reels + Stories + Feed system
- PWA + APK support

TO RUN:
1. Install Node.js
2. Run:
   npm install express socket.io cors
3. Start:
   node backend/server.js

NEXT LEVEL:
- Connect Firebase/Supabase
- Deploy on Vercel/Render
- Build APK using Capacitor or Android Studio