// Socket.io frontend example
const socket = io('http://localhost:3000');

function sendMessage(message) {
  socket.emit('chat-message', message);
}

socket.on('chat-message', (msg) => {
  console.log('New message:', msg);
});